let inputCreate = document.getElementById("input-create");
let buttonCreate = document.getElementById("btn-create");
let inputSearch = document.getElementById("input-search");
let list = document.getElementById("todo-list");
let list2 = document.getElementById("done-list");

buttonCreate.addEventListener('click', function(){
  let value = inputCreate.value;
  let onlyspaces = true;
  let lengthofinput = value.length;
	
  for (let i=0; i < lengthofinput; i++)
  	if (value[i] != " ") onlyspaces = false;
  
  if(onlyspaces == false ){
    addItemToDom(value);
    inputCreate.value = '';
  }
  else if (value) alert("У вас одни пробелы. Не надо так.");
})

function addItemToDom(value){
    let itemView = `
      <div class="item">
        <span class="item-text">${value}</span>
        <span class="secondary-content">
          <div class="item-btn item-btn-done btn-floating btn-small waves-effect waves-light green">v</div>
		  <div class="item-btn item-btn-del btn-floating btn-small waves-effect waves-light red">x</div>
        </span>
      </div>`;

    let item = document.createElement('li');
    //класс, который я не вспомнил на уроке
    item.classList = 'collection-item';
    item.innerHTML = itemView;

    //добавим слушатель для удаления
    let buttonDelete = item.getElementsByClassName('item-btn-del')[0];
    buttonDelete.addEventListener('click', removeItem);
		
	//добавим, пожалуй, слушатель и для переноса в завершенные
	let buttonToDone = item.getElementsByClassName('item-btn-done')[0];
	buttonToDone.addEventListener('click', moveItemToDoneList);

    list.appendChild(item);

}

function removeItem(event){
  let item = event.target.parentNode.parentNode.parentNode;
  list.removeChild(item);
}

function moveItemToDoneList(event){
	let item = event.target.parentNode.parentNode.parentNode;
	let clearbuttons = item.getElementsByClassName('secondary-content')[0];
	
	list.removeChild(item);
	list2.appendChild(item);
	clearbuttons.innerHTML = "";
}

//функция поиска
function search(){
	let list2length = list2.childNodes.length;
	let inputsearchlength = inputSearch.value.length;
	let inputsearchtext = inputSearch.value;

	if (list2length > 0) {	
		for (let i=0; i < list2length; i++) {
			let thislitext = list2.childNodes[i].getElementsByClassName("item-text")[0].textContent;
			list2.childNodes[i].style.display = 'block';
			for (let j=0; j < inputsearchlength; j++) {
				if ( inputsearchtext[j] != thislitext[j] ) 
					list2.childNodes[i].style.display = 'none';

			}
	 	}
	}
}
